#!/bin/sh

adblock_file='/jffs/Adblock/gen_block.txt'
nginx_ip='0.0.0.0'

my_block_list=" \
	254a.com \
	yp.xn--i1b2e6b6ah.com \
"
mylist=`for host in $my_block_list; do echo "127.0.0.1 $host"; done`

yoyo=`curl -qo- 'http://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&mimetype=plaintext'`
if [ $? -eq 0 ]; then
	rm -f $adblock_file
	echo "$mylist\n$yoyo" | uniq -di | grep 127.0.0.1 | awk '{print "Duplicate:",$2}' >&2
	echo "$mylist\n$yoyo" | sort -uf | grep 127.0.0.1 | awk '{print $2}' | \
	while read line; do
		echo "local-zone: \"$line.\" redirect" >> $adblock_file
		echo "local-data: \"$line. 3600 IN A $nginx_ip\"" >> $adblock_file
	done
else
	echo "FAIL TO DOWNLOAD"
fi
