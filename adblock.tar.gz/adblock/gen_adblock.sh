#!/bin/bash
destinationIP="0.0.0.0"
tempoutlist="/jffs/adblock/adlist.tmp"
outlist='/jffs/adblock/tmp.host'
finalist='/jffs/adblock/tmp.finalhost'
permlist='/jffs/adblock/adperm.txt'
adlist='/jffs/adblock/adservers.txt'

echo "Removendo possíveis arquivos temporários.."
[ -f /jffs/adblock/adlist.tmp ] && rm -f /jffs/adblock/adlist.tmp
[ -f /jffs/adblock/tmp.host ] && rm -f /jffs/adblock/tmp.host
[ -f /jffs/adblock/tmp.finalhost ] && rm -f /jffs/adblock/tmp.finalhost
[ -f /jffs/adblock/perm.txt ] && rm -f /jffs/adblock/perm.txt     
#[ -f /jffs/adblock/adperm.txt ] && rm -f /jffs/adblock/adperm.txt

echo "Baixando StevenBlack Adlista..."
curl --progress-bar https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Baixando Disconnect.me 1 Adlista..." 
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_ad.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Baixando Disconnect.me 2 Adlista..." 
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_malvertising.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Baixando Disconnect.me 3 Adlista..." 
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_tracking.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Baixando antipopads Adlista..." 
curl --progress-bar https://raw.githubusercontent.com/Yhonay/antipopads/master/hosts | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Combinando Custom Adlista..."
#curl https://pastebin.com/raw/m7fXS8Ev >> $tempoutlist
cat /jffs/adblock/bloqlist >> $tempoutlist

echo "Removendo formatações duplicadas na lista de domínios..."
cat $tempoutlist | sed -r -e 's/[[:space:]]+/\t/g' | sed -e 's/\t*#.*$//g' | sed -e 's/[^a-zA-Z0-9\.\_\t\-]//g' | sed -e 's/\t$//g' | sed -e '/^#/d' | sort -u | sed '/^$/d' | awk -v "IP=$destinationIP" '{sub(/\r$/,""); print IP" "$0}' > $outlist
numberOfAdsBlocked=$(cat $outlist | wc -l | sed 's/^[ \t]*//')
echo "$numberOfAdsBlocked domínios compilados"

echo "Editar a lista de domínios permitidos..."
#curl --progress-bar https://raw.githubusercontent.com/anudeepND/whitelist/master/domains/whitelist.txt >> /jffs/Adblock/perm.txt
#cat /jffs/adblock/perm.txt /jffs/adblock/pattern.txt > $permlist
fgrep -vf $permlist $outlist  > $finalist

echo "Gerando Adlista Unbound..."
cat $finalist | grep '^0\.0\.0\.0' | awk '{print "local-zone: \""$2"\" static"}' > $adlist
#cat $finalist | grep '^0\.0\.0\.0' | awk '{ print "local-zone: \""$2"\" redirect\nlocal-data: \""$2" A 0.0.0.0\"" }' > $adlist
numberOfAdsBlocked=$(cat $adlist | wc -l | sed 's/^[ \t]*//')
echo "$numberOfAdsBlocked domínios suspeitos e bloqueados"

echo "Removendo arquivos temporários.."
[ -f /jffs/adblock/adlist.tmp ] && rm -f /jffs/adblock/adlist.tmp
[ -f /jffs/adblock/tmp.host ] && rm -f /jffs/adblock/tmp.host
[ -f /jffs/adblock/tmp.finalhost ] && rm -f /jffs/adblock/tmp.finalhost
[ -f /jffs/adblock/perm.txt ] && rm -f /jffs/adblock/perm.txt
#[ -f /jffs/adblock/adperm.txt ] && rm -f /jffs/Adblock/adperm.txt
echo "Baixando root servers DNS.."
curl -o /opt/var/lib/unbound/root.hints https://www.internic.net/domain/named.cache
echo "Reiniciando servidores DNS.."
/opt/etc/init.d/S61unbound restart
