#!/bin/bash
destinationIP="0.0.0.0"
tempoutlist="/jffs/adblock/adlist.tmp"
outlist='/jffs/adblock/tmp.host'
finalist='/jffs/adblock/tmp.finalhost'
permlist='/jffs/adblock/permlist'
adlist='/jffs/adblock/adservers'

echo "Removing possible temporary files.."
[ -f /jffs/adblock/adlist.tmp ] && rm -f /jffs/adblock/adlist.tmp
[ -f /jffs/adblock/tmp.host ] && rm -f /jffs/adblock/tmp.host
[ -f /jffs/adblock/tmp.finalhost ] && rm -f /jffs/adblock/tmp.finalhost

echo "Dowloading StevenBlack Adlist..."
curl --progress-bar https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Dowloading Disconnect.me 1 Adlist..."
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_ad.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Dowloading Disconnect.me 2 Adlist..."
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_malvertising.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Dowloading Disconnect.me 3 Adlist..."
curl --progress-bar https://s3.amazonaws.com/lists.disconnect.me/simple_tracking.txt | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist
echo "Dowloading antipopads Adlist..."
curl --progress-bar https://raw.githubusercontent.com/Yhonay/antipopads/master/hosts | grep -v "#" | grep -v "::1" | grep -v "0.0.0.0 0.0.0.0" | sed '/^$/d' | sed 's/\ /\\ /g' | awk '{print $2}' | grep -v '^\\' | grep -v '\\$'| sort >> $tempoutlist

echo "Combining User Custom block host..."
cat /jffs/adblock/blockhost >> $tempoutlist

echo "Removing duplicate formatting from the domain list..."
cat $tempoutlist | sed -r -e 's/[[:space:]]+/\t/g' | sed -e 's/\t*#.*$//g' | sed -e 's/[^a-zA-Z0-9\.\_\t\-]//g' | sed -e 's/\t$//g' | sed -e '/^#/d' | sort -u | sed '/^$/d' | awk -v "IP=$destinationIP" '{sub(/\r$/,""); print IP" "$0}' > $outlist
numberOfAdsBlocked=$(cat $outlist | wc -l | sed 's/^[ \t]*//')
echo "$numberOfAdsBlocked domains compiled"

echo "Edit User Custon list of allowed domains..."
fgrep -vf $permlist $outlist  > $finalist

echo "Generating Unbound adlist....."
cat $finalist | grep '^0\.0\.0\.0' | awk '{print "local-zone: \""$2"\" static"}' > $adlist
numberOfAdsBlocked=$(cat $adlist | wc -l | sed 's/^[ \t]*//')
echo "$numberOfAdsBlocked suspicious and blocked domains"

echo "Removing temporary files..."
[ -f /jffs/adblock/adlist.tmp ] && rm -f /jffs/adblock/adlist.tmp
[ -f /jffs/adblock/tmp.host ] && rm -f /jffs/adblock/tmp.host
[ -f /jffs/adblock/tmp.finalhost ] && rm -f /jffs/adblock/tmp.finalhost
[ -f /jffs/adblock/perm.txt ] && rm -f /jffs/adblock/perm.txt

echo "Dowloading root servers DNS..."
curl -o /opt/var/lib/unbound/root.hints https://www.internic.net/domain/named.cache
echo "Restarting DNS servers..."
/opt/etc/init.d/S61unbound restart
